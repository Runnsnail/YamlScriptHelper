package com.wd.yh.action;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.CommonDataKeys;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiDirectory;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiFileFactory;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.yaml.YAMLFileType;

public class GenerateYamlTemplateAction extends AnAction {

    @Override
    public void actionPerformed(@NotNull AnActionEvent e) {
        Project project = e.getProject();
        if (project == null) {
            return;
        }

        String fileName = Messages.showInputDialog(project, "Enter file name (e.g., template.yaml):", "Generate YAML Template", Messages.getQuestionIcon());
        if (fileName == null || fileName.trim().isEmpty()) {
            return;
        }

        if (!fileName.toLowerCase().endsWith(".yaml") && !fileName.toLowerCase().endsWith(".yml")) {
            fileName += ".yaml";
        }

        VirtualFile selectedFile = e.getData(CommonDataKeys.VIRTUAL_FILE);
        PsiDirectory directory = null;
        if (selectedFile != null) {
            if (selectedFile.isDirectory()) {
                directory = project.getService(com.intellij.psi.PsiManager.class).findDirectory(selectedFile);
            } else {
                directory = project.getService(com.intellij.psi.PsiManager.class).findDirectory(selectedFile.getParent());
            }
        }

        if (directory == null) {
            // Fallback to project base directory if no directory is selected or found
            VirtualFile baseDir = project.getBaseDir();
            if (baseDir != null) {
                 directory = project.getService(com.intellij.psi.PsiManager.class).findDirectory(baseDir);
            }
        }
        
        if (directory == null) {
            Messages.showErrorDialog(project, "Cannot determine target directory.", "Error");
            return;
        }

        String templateContent = "description: Parallel execution demo script\n" +
                                 "input: [mobileNumber, pin, amountInCents = 1]\n" +
                                 "output: []\n" +
                                 "tags: []\n" +
                                 "executions:\n" +
                                 "  sbx:\n" +
                                 "    android: [mobileNumber = '198940849', pin = '111222']\n" +
                                 "    ios: [mobileNumber = '199067067', pin = '111222']\n" +
                                 "steps:\n" +
                                 "  - refer demo-script-base(mobileNumber = ${mobileNumber}, pin = ${pin})\n";

        PsiDirectory finalDirectory = directory;
        String finalFileName = fileName;
        WriteCommandAction.runWriteCommandAction(project, () -> {
            try {
                PsiFile existingFile = finalDirectory.findFile(finalFileName);
                if (existingFile != null) {
                    Messages.showWarningDialog(project, "File '" + finalFileName + "' already exists.", "File Exists");
                    return;
                }
                PsiFile psiFile = PsiFileFactory.getInstance(project).createFileFromText(finalFileName, YAMLFileType.YML, templateContent);
                finalDirectory.add(psiFile);
                // Open the newly created file in the editor
                VirtualFile virtualFile = psiFile.getVirtualFile();
                if (virtualFile != null) {
                    FileEditorManager.getInstance(project).openFile(virtualFile, true);
                }
            } catch (IncorrectOperationException ex) {
                Messages.showErrorDialog(project, "Error creating file: " + ex.getMessage(), "Error");
            }
        });
    }

    @Override
    public void update(@NotNull AnActionEvent e) {
        Project project = e.getProject();
        e.getPresentation().setEnabledAndVisible(project != null);
    }
}