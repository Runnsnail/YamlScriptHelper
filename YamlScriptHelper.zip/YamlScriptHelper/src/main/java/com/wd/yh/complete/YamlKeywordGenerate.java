package com.wd.yh.complete;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import com.wd.yh.gui.YamlGui;
import com.wd.yh.persistent.YamlPersistent;
import com.wd.yh.util.JsonUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

public class YamlKeywordGenerate {

    public static List<String> getKeywords() {
        List<String> keys = new ArrayList<>();
        YamlPersistent instance = YamlPersistent.getInstance();
        String yamlFilePath = instance.getYamlFilePath();
        if (StrUtil.isNotBlank(yamlFilePath)) {
            JSONObject object = JsonUtil.toObject(YamlGui.getJson(yamlFilePath), JSONObject.class);
            for (Entry<String, Object> entry : object) {
                keys.add(entry.getKey() + "-#-" + entry.getValue());
            }
        }
        // Add predefined script tags based on all-step-quick-reference.yaml
        keys.add("description-#-Describes the purpose of the script");
        keys.add("input-#-Defines input parameters for the script");
        keys.add("output-#-Defines output parameters for the script");
        keys.add("tags-#-System tags for script categorization (e.g., local, regression)");
        keys.add("executions-#-Defines execution configurations for different environments");
        keys.add("steps-#-A list of steps to be executed");

        // Steps from the reference file
        keys.add("set-#-set <variableName> = <expression>");
        keys.add("call-#-call <functionName>(<arguments>) [ -> <output assignment into multiple variables>]");
        keys.add("refer-#-refer <scriptName>(<arguments>) [ -> <output assignment into multiple variables>]");
        keys.add("spot-#-spot [no] { ( <textElementLocatorStrategy> '<text>' ) | ( image from <imageFileName> ) } [@<index>] [within <timeout>s]");
        keys.add("assert-#-assert <expression> [within <timeout>s]");
        keys.add("tap-#-tap { '<text>' | ( { xpath | id } '<locatorValue>' ) [@<index>] } [within <timeout>s]");
        keys.add("input-#-input '<text>'");
        keys.add("getText-#-getText { xpath | id } '<locatorValue>' [@<index>] [within <timeout>s]");
        keys.add("clearText-#-clearText");
        keys.add("swipe-#-swipe <direction: up, down, left, right>");
        keys.add("fail-#-fail");
        keys.add("if-#-if <expression or spot step>:");
        keys.add("else if-#-else if <expression or spot step>:");
        keys.add("else-#-else <expression or spot step>:");
        keys.add("while-#-while <expression or spot step> [maximum <maxNumberOfAttempts>t or <overallTimeout>s]:");
        keys.add("navigateBack-#-navigateBack");
        keys.add("openLink-#-openLink '<uri>'");
        keys.add("uploadFile-#-uploadFile from <sourceFilePath>");
        keys.add("restartApp-#-restartApp");

        // Supported expressions - these might be too generic for direct keyword completion but good for documentation
        // keys.add("true-#-Boolean true value");
        // keys.add("false-#-Boolean false value");
        // keys.add("android-#-Platform check: android");
        // keys.add("ios-#-Platform check: ios");

        return keys;
    }
   
}